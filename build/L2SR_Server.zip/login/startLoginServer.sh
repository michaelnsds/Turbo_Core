#!/bin/bash

./LoginServer_loop.sh &
